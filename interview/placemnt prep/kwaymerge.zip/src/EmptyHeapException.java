/**
 * EmptyHeapException
 * 
 * @author Donald Chinn
 * @version September 19, 2003
 */
public class EmptyHeapException extends Exception {
}
